package com.tech.firebasetagf

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
